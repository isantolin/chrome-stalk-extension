chrome-stalk-extension
======================

It's a tool to reduce risks when stalks someone
